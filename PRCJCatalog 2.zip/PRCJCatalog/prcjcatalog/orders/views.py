from django.shortcuts import render
from orders.models import Orders, OrderDetails
from orders.serializers import OrderSerializer, OrderItemSerialzier
from rest_framework import generics, permissions, status

# Create your views here.

# Order View - Create, retrieve, update, Destroy
class listOrdersView(generics.ListCreateAPIView):
    queryset = Orders.objects.all()
    serializer_class = OrderSerializer

class modifyOrderView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Orders.objects.all()
    serializer_class = OrderSerializer

# OrderItem View - create, retrieve, update, destroy
class listOrderItemView(generics.ListCreateAPIView):
    queryset = OrderDetails.objects.all()
    serializer_class = OrderItemSerialzier

class modifyOrderItemView(generics.RetrieveUpdateDestroyAPIView):
    queryset = OrderDetails.objects.all()
    serializer_class = OrderItemSerialzier
