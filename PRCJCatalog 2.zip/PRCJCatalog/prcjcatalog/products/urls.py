from django.urls import path
from products import views

urlpatterns = [
    path("category/", views.listCategoryView.as_view()),
    path("gold-price/", views.createGoldPriceView.as_view()),
    path("gold-price-update/<int:pk>", views.updateGoldPriceView.as_view()),
    path("details/", views.listProductsView.as_view()),
    path("details/<int:pk>", views.getProductsView.as_view()),
    path("list/", views.listPriceView.as_view()),
    path("list/<int:pk>", views.getPriceView.as_view()),
]