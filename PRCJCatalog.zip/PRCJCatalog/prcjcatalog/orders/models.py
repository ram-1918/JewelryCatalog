from django.db import models
from users.models import Users
from products.models import Category, Products, GoldPrice, Price

# Create your models here.

class Orders(models.Model):
    account = models.ForeignKey(
        "Users", related_name = "map_user", on_delete = models.CASCADE
    )
    products = models.ManyToManyField(
        "Products", through = "OrderDetails"
    )
    date = models.DateTimeField(auto_now_add= True)
    totalcost = models.DecimalField(max_digits = 10, decimal_places = 3)
    status = models.CharField(max_length = 255)

    def __str__(self):
        return f"Order {self.pk}"

class OrderDetails(models.Model):
    order = models.ForeignKey(
        "Orders", related_name = "map_order", on_delete = models.CASCADE
    )
    product = models.ForeignKey(
        "Products", related_name= "map_product",  on_delete = models.CASCADE
    )
    quantity = models.PositiveIntegerField()
    price = models.DecimalField(max_digits = 10, decimal_places = 3)

    def __str__(self):
        return f'{self.quantity}x{self.product.name}'