from rest_framework import serializers
from users.models import Users, Products, Price, GoldPrice, Category, Orders, OrderDetails

class AccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = Users
        fields = '__all__'

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Products
        fields = '__all__'

class PriceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Price
        fields = '__all__'

class GoldPriceSerializer(serializers.ModelSerializer):
    class Meta:
        model = GoldPrice
        fields = '__all__'

class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Orders
        fields = '__all__'

class OrderItemSerialzier(serializers.ModelSerializer):
    class Meta:
        model = OrderDetails
        fields = '__all__'