from django.urls import path, include
from users import views

urlpatterns = [
    path("create_user/", views.createUserView.as_view()),
    path("modify_user/<int:pk>", views.modifyUserView.as_view()),
    path("productsdetails/", views.listProductsView.as_view()),
    path("productsdetails/<int:pk>", views.getProductsView.as_view()),
    path("products/", views.listPriceView.as_view()),
    path("products/<int:pk>", views.getPriceView.as_view()),
    path("gprice/", views.createGoldPriceView.as_view()),
    path("gprice/<int:pk>", views.updateGoldPriceView.as_view()),
    path("category/", views.listCategoryView.as_view()),
    path("orders/", views.listOrdersView.as_view()),
    path("modify_orders/<int:pk>", views.modifyOrderView.as_view()),
    path("items/", views.listOrderItemView.as_view()),
    path("modify_item/<int:pk>", views.modifyOrderItemView.as_view()),
]