from django.shortcuts import render
from users.models import Users, Products, Price, GoldPrice, Category, Orders, OrderDetails
from users.serializers import AccountSerializer, ProductSerializer, PriceSerializer, GoldPriceSerializer, CategorySerializer, OrderSerializer, OrderItemSerialzier
from rest_framework import generics, permissions, status
from django.db.models import F # Used to updating a column value by adding, multiplying, dividing.. a scalar to it 

# Create your views here.
# If issues occur when migrating then use "python manage.py migrate --fake", it fakes the migration
# def save(self, *args, **kwargs) method in models to update a column value right at database level
# CharField - choices; imageField - upload_to; DateTimeField - auto_now_add; DecimaField - max-digits; 

# User View - create, retrieve, update, destroy
class createUserView(generics.CreateAPIView):
    queryset = Users.objects.all()
    serializer_class = AccountSerializer

class modifyUserView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Users.objects.all()
    serializer_class = AccountSerializer

# Product View - list
class listProductsView(generics.ListCreateAPIView):
    # goldprice = 192.23
    # Products.objects.update(price = F('price')*goldprice)
    # print(Products.objects.all())
    # print("select ", Products.objects.select_related('category').all())
    # print("prefetch_related ", Products.objects.prefetch_related('category').all())
    queryset = Products.objects.all() #prefetch_related('price').all()
    serializer_class = ProductSerializer

class getProductsView(generics.RetrieveAPIView):
    queryset = Products.objects.all()
    serializer_class = ProductSerializer

# Products with prices view
class listPriceView(generics.ListCreateAPIView):
    queryset = Price.objects.all()
    serializer_class = PriceSerializer

class getPriceView(generics.RetrieveAPIView):
    queryset = Price.objects.all()
    serializer_class = PriceSerializer

# Gold Price (Should be an API call to get LIVE price)
class createGoldPriceView(generics.CreateAPIView):
    queryset = GoldPrice.objects.all()
    serializer_class = GoldPriceSerializer

class updateGoldPriceView(generics.RetrieveUpdateAPIView):
    queryset = GoldPrice.objects.all()
    serializer_class = GoldPriceSerializer

# Category View - list
class listCategoryView(generics.ListCreateAPIView):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer

# Order View - Create, retrieve, update, Destroy
class listOrdersView(generics.ListCreateAPIView):
    queryset = Orders.objects.all()
    serializer_class = OrderSerializer

class modifyOrderView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Orders.objects.all()
    serializer_class = OrderSerializer

# OrderItem View - create, retrieve, update, destroy
class listOrderItemView(generics.ListCreateAPIView):
    #product_price = Products.objects.filter()
    #OrderDetails.objects.update(price = product_price*F('quantity'))
    queryset = OrderDetails.objects.all()
    serializer_class = OrderItemSerialzier

class modifyOrderItemView(generics.RetrieveUpdateDestroyAPIView):
    queryset = OrderDetails.objects.all()
    serializer_class = OrderItemSerialzier



